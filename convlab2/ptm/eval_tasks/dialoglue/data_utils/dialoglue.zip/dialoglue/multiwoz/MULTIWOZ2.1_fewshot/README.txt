Note that this is the mid 2019 version of MultiWOZ 2.1.
The dataset has since been updated and the most recent version will therefore differ
from the version we used for the experiments that we report in arXiv:2005.02877
